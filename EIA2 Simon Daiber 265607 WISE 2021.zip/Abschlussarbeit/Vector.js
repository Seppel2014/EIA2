"use strict";
var Abschlussarbeit;
(function (Abschlussarbeit) {
    class Vector {
        x;
        y;
        constructor(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
    }
    Abschlussarbeit.Vector = Vector;
})(Abschlussarbeit || (Abschlussarbeit = {}));
//# sourceMappingURL=Vector.js.map
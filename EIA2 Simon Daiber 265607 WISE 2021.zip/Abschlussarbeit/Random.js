"use strict";
var Abschlussarbeit;
(function (Abschlussarbeit) {
    function randomNumber(_min, _max) {
        return Math.floor(Math.random() * (_max - _min) + _min);
    }
    Abschlussarbeit.randomNumber = randomNumber;
})(Abschlussarbeit || (Abschlussarbeit = {}));
//# sourceMappingURL=Random.js.map